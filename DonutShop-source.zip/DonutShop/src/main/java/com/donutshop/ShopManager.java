package com.donutshop;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class ShopManager {

    public record Item(Material material, double buy, double sell) {}

    public static final class Category {
        public final String id;
        public final String name;
        public final Material icon;
        public final int slot;
        public final List<Item> items = new ArrayList<>();

        Category(String id, String name, Material icon, int slot) {
            this.id = id;
            this.name = name;
            this.icon = icon;
            this.slot = slot;
        }
    }

    private final DonutShop plugin;
    private final Map<String, Category> categories = new LinkedHashMap<>();
    private final Map<Material, Double> sellPrices = new HashMap<>();
    private final Set<Material> blocked = EnumSet.noneOf(Material.class);

    public ShopManager(DonutShop plugin) {
        this.plugin = plugin;
    }

    public void load() {
        categories.clear();
        sellPrices.clear();
        blocked.clear();

        for (String s : plugin.getConfig().getStringList("blocked-materials")) {
            Material m = Material.matchMaterial(s);
            if (m != null) blocked.add(m);
        }

        File f = new File(plugin.getDataFolder(), "shop.yml");
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection cs = yml.getConfigurationSection("categories");
        if (cs == null) {
            plugin.getLogger().warning("shop.yml sem a seção 'categories'.");
            return;
        }

        for (String id : cs.getKeys(false)) {
            ConfigurationSection c = cs.getConfigurationSection(id);
            if (c == null) continue;

            Material icon = Material.matchMaterial(c.getString("icon", "CHEST"));
            if (icon == null) icon = Material.CHEST;
            Category cat = new Category(id, c.getString("name", id), icon, c.getInt("slot", 10 + categories.size()));

            for (String line : c.getStringList("items")) {
                String[] p = line.trim().split("\\s+");
                if (p.length < 2) {
                    plugin.getLogger().warning("[" + id + "] linha inválida: " + line);
                    continue;
                }
                Material m = Material.matchMaterial(p[0]);
                if (m == null || !m.isItem()) {
                    plugin.getLogger().warning("[" + id + "] material inválido: " + p[0]);
                    continue;
                }
                if (isBlocked(m)) {
                    plugin.getLogger().warning("[" + id + "] material bloqueado ignorado: " + m);
                    continue;
                }
                double buy;
                double sell;
                try {
                    buy = EconomyManager.parse(p[1]);
                    sell = p.length > 2 ? EconomyManager.parse(p[2]) : 0;
                } catch (NumberFormatException ex) {
                    plugin.getLogger().warning("[" + id + "] preço inválido: " + line);
                    continue;
                }
                if (buy > 0) cat.items.add(new Item(m, buy, sell));
                if (sell > 0) sellPrices.putIfAbsent(m, sell);
            }
            categories.put(id, cat);
        }
    }

    /** Spawners (qualquer tipo) são sempre bloqueados, mesmo que alguém edite o config. */
    public boolean isBlocked(Material m) {
        return m.name().contains("SPAWNER") || blocked.contains(m);
    }

    public double sellPrice(Material m) {
        if (isBlocked(m)) return 0;
        return sellPrices.getOrDefault(m, 0.0);
    }

    public Collection<Category> categories() {
        return categories.values();
    }

    public static String pretty(Material m) {
        StringBuilder sb = new StringBuilder();
        for (String w : m.name().toLowerCase(Locale.ROOT).split("_")) {
            if (w.isEmpty()) continue;
            if (sb.length() > 0) sb.append(' ');
            sb.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1));
        }
        return sb.toString();
    }
}
