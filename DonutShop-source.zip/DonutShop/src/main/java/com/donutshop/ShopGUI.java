package com.donutshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ShopGUI implements Listener {

    // ---------- holders ----------
    public abstract static class Holder implements InventoryHolder {
        Inventory inventory;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    public static final class MainHolder extends Holder {}

    public static final class SellHolder extends Holder {}

    public static final class CategoryHolder extends Holder {
        final ShopManager.Category category;
        final int page;

        CategoryHolder(ShopManager.Category category, int page) {
            this.category = category;
            this.page = page;
        }
    }

    public static final class BuyHolder extends Holder {
        final ShopManager.Category category;
        final int page;
        final ShopManager.Item item;
        int amount = 1;

        BuyHolder(ShopManager.Category category, int page, ShopManager.Item item) {
            this.category = category;
            this.page = page;
            this.item = item;
        }
    }

    private static final int PER_PAGE = 45;

    private final DonutShop plugin;
    private final EconomyManager eco;
    private final ShopManager shop;

    public ShopGUI(DonutShop plugin, EconomyManager eco, ShopManager shop) {
        this.plugin = plugin;
        this.eco = eco;
        this.shop = shop;
    }

    // ---------- helpers ----------
    private List<Component> colorLines(List<String> lines) {
        List<Component> out = new ArrayList<>();
        for (String l : lines) out.add(plugin.color(l).decoration(TextDecoration.ITALIC, false));
        return out;
    }

    private ItemStack button(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(plugin.color(name).decoration(TextDecoration.ITALIC, false));
        if (lore.length > 0) meta.lore(colorLines(Arrays.asList(lore)));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    private ItemStack itemWithLore(Material m, int amount, List<String> lore) {
        ItemStack it = new ItemStack(m, amount);
        ItemMeta meta = it.getItemMeta();
        meta.lore(colorLines(lore));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        it.setItemMeta(meta);
        return it;
    }

    private void fill(Inventory inv, int from, int to) {
        ItemStack filler = button(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = from; i < to; i++) inv.setItem(i, filler);
    }

    private void ok(Player p) {
        p.playSound(p.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1f, 1f);
    }

    private void deny(Player p) {
        p.playSound(p.getLocation(), Sound.ENTITY_VILLAGER_NO, 1f, 1f);
    }

    private int pages(ShopManager.Category cat) {
        return Math.max(1, (cat.items.size() + PER_PAGE - 1) / PER_PAGE);
    }

    // ---------- menu principal ----------
    public void openMain(Player p) {
        MainHolder h = new MainHolder();
        Inventory inv = Bukkit.createInventory(h, 27, plugin.color("&8Loja"));
        h.inventory = inv;
        fill(inv, 0, 27);
        for (ShopManager.Category c : shop.categories()) {
            if (c.slot >= 0 && c.slot < 27) {
                inv.setItem(c.slot, button(c.icon, c.name,
                        "&7" + c.items.size() + " itens", "", "&eClique para abrir"));
            }
        }
        inv.setItem(22, button(Material.GOLD_INGOT, "&6Saldo: &f" + eco.format(eco.get(p.getUniqueId()))));
        inv.setItem(26, button(Material.HOPPER, "&aVender itens",
                "&7Coloque itens no menu e", "&7feche para vender.", "", "&eClique para abrir"));
        p.openInventory(inv);
    }

    // ---------- categoria ----------
    public void openCategory(Player p, ShopManager.Category cat, int page) {
        int total = pages(cat);
        page = Math.max(0, Math.min(page, total - 1));

        CategoryHolder h = new CategoryHolder(cat, page);
        Component title = Component.text("Loja » ", NamedTextColor.DARK_GRAY).append(plugin.color(cat.name));
        Inventory inv = Bukkit.createInventory(h, 54, title);
        h.inventory = inv;

        int start = page * PER_PAGE;
        for (int i = 0; i < PER_PAGE && start + i < cat.items.size(); i++) {
            ShopManager.Item it = cat.items.get(start + i);
            List<String> lore = new ArrayList<>();
            lore.add("&7Comprar: &a" + eco.format(it.buy()));
            if (it.sell() > 0) lore.add("&7Vender: &e" + eco.format(it.sell()));
            lore.add("");
            lore.add("&eClique para comprar");
            inv.setItem(i, itemWithLore(it.material(), 1, lore));
        }

        fill(inv, PER_PAGE, 54);
        inv.setItem(45, button(Material.ARROW, "&cVoltar"));
        if (page > 0) inv.setItem(48, button(Material.ARROW, "&ePágina anterior", "&7Página " + page + "/" + total));
        inv.setItem(49, button(Material.GOLD_INGOT, "&6Saldo: &f" + eco.format(eco.get(p.getUniqueId()))));
        if (page < total - 1) inv.setItem(50, button(Material.ARROW, "&ePróxima página", "&7Página " + (page + 2) + "/" + total));
        p.openInventory(inv);
    }

    // ---------- compra ----------
    public void openBuy(Player p, ShopManager.Category cat, int page, ShopManager.Item item) {
        BuyHolder h = new BuyHolder(cat, page, item);
        Inventory inv = Bukkit.createInventory(h, 27,
                Component.text("Comprar » ", NamedTextColor.DARK_GRAY).append(Component.text(ShopManager.pretty(item.material()))));
        h.inventory = inv;
        renderBuy(h, p);
        p.openInventory(inv);
    }

    private void renderBuy(BuyHolder h, Player p) {
        Inventory inv = h.inventory;
        fill(inv, 0, 27);
        ShopManager.Item it = h.item;
        double total = EconomyManager.round(it.buy() * h.amount);

        inv.setItem(13, itemWithLore(it.material(), h.amount, List.of(
                "&7Preço unitário: &a" + eco.format(it.buy()),
                "&7Quantidade: &f" + h.amount,
                "&7Total: &a" + eco.format(total))));

        inv.setItem(9, button(Material.WHITE_STAINED_GLASS_PANE, "&fMínimo &7(1)"));
        inv.setItem(10, button(Material.RED_STAINED_GLASS_PANE, "&c-10"));
        inv.setItem(11, button(Material.RED_STAINED_GLASS_PANE, "&c-1"));
        inv.setItem(15, button(Material.LIME_STAINED_GLASS_PANE, "&a+1"));
        inv.setItem(16, button(Material.LIME_STAINED_GLASS_PANE, "&a+10"));
        inv.setItem(17, button(Material.WHITE_STAINED_GLASS_PANE, "&fMáximo &7(64)"));
        inv.setItem(18, button(Material.ARROW, "&cVoltar"));
        inv.setItem(22, button(Material.LIME_CONCRETE, "&a&lConfirmar compra",
                "&7" + h.amount + "x " + ShopManager.pretty(it.material()),
                "&7Total: &a" + eco.format(total),
                "",
                "&7Seu saldo: &f" + eco.format(eco.get(p.getUniqueId()))));
    }

    private int freeSpace(Player p, Material m) {
        int max = m.getMaxStackSize();
        int space = 0;
        ItemStack probe = new ItemStack(m);
        for (ItemStack s : p.getInventory().getStorageContents()) {
            if (s == null || s.getType().isAir()) space += max;
            else if (s.isSimilar(probe)) space += Math.max(0, max - s.getAmount());
        }
        return space;
    }

    private void give(Player p, Material m, int amount) {
        int max = m.getMaxStackSize();
        int left = amount;
        while (left > 0) {
            int n = Math.min(max, left);
            Map<Integer, ItemStack> over = p.getInventory().addItem(new ItemStack(m, n));
            for (ItemStack o : over.values()) p.getWorld().dropItemNaturally(p.getLocation(), o);
            left -= n;
        }
    }

    private void purchase(Player p, BuyHolder h) {
        Material m = h.item.material();
        int amount = h.amount;
        UUID id = p.getUniqueId();

        if (shop.isBlocked(m)) {
            deny(p);
            return;
        }
        double total = EconomyManager.round(h.item.buy() * amount);
        if (!eco.has(id, total)) {
            deny(p);
            p.sendMessage(plugin.msg("not-enough-money", "price", eco.format(total), "balance", eco.format(eco.get(id))));
            return;
        }
        if (freeSpace(p, m) < amount) {
            deny(p);
            p.sendMessage(plugin.msg("no-space"));
            return;
        }
        eco.withdraw(id, total);
        give(p, m, amount);
        ok(p);
        p.sendMessage(plugin.msg("bought", "amount", amount, "item", ShopManager.pretty(m), "price", eco.format(total)));
    }

    // ---------- venda ----------
    public void openSell(Player p) {
        SellHolder h = new SellHolder();
        Inventory inv = Bukkit.createInventory(h, 54, plugin.color("&8Vender itens"));
        h.inventory = inv;
        p.openInventory(inv);
    }

    private boolean sellable(ItemStack it) {
        return !it.hasItemMeta() && shop.sellPrice(it.getType()) > 0;
    }

    @EventHandler
    public void onClose(InventoryCloseEvent e) {
        Inventory inv = e.getInventory();
        if (!(inv.getHolder() instanceof SellHolder)) return;
        if (!(e.getPlayer() instanceof Player p)) return;

        double total = 0;
        int count = 0;
        List<ItemStack> back = new ArrayList<>();
        for (ItemStack it : inv.getContents()) {
            if (it == null || it.getType().isAir()) continue;
            if (sellable(it)) {
                total += shop.sellPrice(it.getType()) * it.getAmount();
                count += it.getAmount();
            } else {
                back.add(it);
            }
        }
        inv.clear();

        for (ItemStack it : back) {
            for (ItemStack o : p.getInventory().addItem(it).values()) {
                p.getWorld().dropItemNaturally(p.getLocation(), o);
            }
        }

        total = EconomyManager.round(total);
        if (total > 0) {
            eco.add(p.getUniqueId(), total);
            ok(p);
            p.sendMessage(plugin.msg("sold", "amount", count, "price", eco.format(total)));
        }
        if (!back.isEmpty()) p.sendMessage(plugin.msg("returned"));
    }

    // ---------- cliques ----------
    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        InventoryHolder raw = e.getView().getTopInventory().getHolder();
        if (raw instanceof Holder && !(raw instanceof SellHolder)) e.setCancelled(true);
    }

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        InventoryHolder raw = top.getHolder();
        if (!(raw instanceof Holder) || raw instanceof SellHolder) return;

        e.setCancelled(true);
        if (!(e.getWhoClicked() instanceof Player p)) return;
        Inventory clicked = e.getClickedInventory();
        if (clicked == null || !clicked.equals(top)) return;
        int slot = e.getRawSlot();

        if (raw instanceof MainHolder) {
            if (slot == 26) {
                openSell(p);
                return;
            }
            for (ShopManager.Category c : shop.categories()) {
                if (c.slot == slot) {
                    openCategory(p, c, 0);
                    return;
                }
            }
        } else if (raw instanceof CategoryHolder ch) {
            if (slot >= 0 && slot < PER_PAGE) {
                int idx = ch.page * PER_PAGE + slot;
                if (idx < ch.category.items.size()) openBuy(p, ch.category, ch.page, ch.category.items.get(idx));
            } else if (slot == 45) {
                openMain(p);
            } else if (slot == 48 && ch.page > 0) {
                openCategory(p, ch.category, ch.page - 1);
            } else if (slot == 50 && ch.page < pages(ch.category) - 1) {
                openCategory(p, ch.category, ch.page + 1);
            }
        } else if (raw instanceof BuyHolder bh) {
            switch (slot) {
                case 9 -> bh.amount = 1;
                case 10 -> bh.amount = Math.max(1, bh.amount - 10);
                case 11 -> bh.amount = Math.max(1, bh.amount - 1);
                case 15 -> bh.amount = Math.min(64, bh.amount + 1);
                case 16 -> bh.amount = Math.min(64, bh.amount + 10);
                case 17 -> bh.amount = 64;
                case 18 -> {
                    openCategory(p, bh.category, bh.page);
                    return;
                }
                case 22 -> purchase(p, bh);
                default -> {
                    return;
                }
            }
            renderBuy(bh, p);
        }
    }
}
