package com.donutshop;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;

public final class DonutShop extends JavaPlugin implements Listener {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private EconomyManager economy;
    private ShopManager shop;
    private ShopGUI gui;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (!new File(getDataFolder(), "shop.yml").exists()) {
            saveResource("shop.yml", false);
        }

        economy = new EconomyManager(this);
        shop = new ShopManager(this);
        gui = new ShopGUI(this, economy, shop);
        economy.load();
        shop.load();

        Bukkit.getPluginManager().registerEvents(this, this);
        Bukkit.getPluginManager().registerEvents(gui, this);

        Commands handler = new Commands(this, economy, gui);
        for (String name : new String[]{"shop", "sell", "balance", "pay", "baltop", "eco"}) {
            PluginCommand cmd = getCommand(name);
            if (cmd != null) {
                cmd.setExecutor(handler);
                cmd.setTabCompleter(handler);
            }
        }

        // salva a economia a cada 5 minutos
        Bukkit.getScheduler().runTaskTimer(this, economy::save, 6000L, 6000L);
        getLogger().info("DonutShop ativado: " + shop.categories().size() + " categorias carregadas.");
    }

    @Override
    public void onDisable() {
        // fecha menus de venda abertos para devolver/pagar os itens antes de desligar
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof ShopGUI.SellHolder) {
                p.closeInventory();
            }
        }
        if (economy != null) economy.save();
    }

    public void reloadAll() {
        reloadConfig();
        shop.load();
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent e) {
        economy.touch(e.getPlayer());
    }

    public Component color(String s) {
        return LEGACY.deserialize(s);
    }

    public Component msg(String key, Object... kv) {
        String s = getConfig().getString("messages." + key, "&cMensagem ausente: " + key);
        for (int i = 0; i + 1 < kv.length; i += 2) {
            s = s.replace("{" + kv[i] + "}", String.valueOf(kv[i + 1]));
        }
        return color(getConfig().getString("messages.prefix", "") + s);
    }
}
