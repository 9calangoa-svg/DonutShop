package com.donutshop;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class Commands implements CommandExecutor, TabCompleter {

    private static final String ADMIN = "donutshop.admin";

    private final DonutShop plugin;
    private final EconomyManager eco;
    private final ShopGUI gui;

    public Commands(DonutShop plugin, EconomyManager eco, ShopGUI gui) {
        this.plugin = plugin;
        this.eco = eco;
        this.gui = gui;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        switch (cmd.getName().toLowerCase(Locale.ROOT)) {
            case "shop" -> shop(sender, args);
            case "sell" -> {
                if (sender instanceof Player p) gui.openSell(p);
                else sender.sendMessage(plugin.msg("players-only"));
            }
            case "balance" -> balance(sender, args);
            case "pay" -> pay(sender, args);
            case "baltop" -> baltop(sender);
            case "eco" -> ecoAdmin(sender, args);
            default -> {
                return false;
            }
        }
        return true;
    }

    private void shop(CommandSender s, String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("reload")) {
            if (!s.hasPermission(ADMIN)) {
                s.sendMessage(plugin.msg("no-permission"));
                return;
            }
            plugin.reloadAll();
            s.sendMessage(plugin.msg("reloaded"));
            return;
        }
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.msg("players-only"));
            return;
        }
        gui.openMain(p);
    }

    private void balance(CommandSender s, String[] args) {
        if (args.length == 0) {
            if (!(s instanceof Player p)) {
                s.sendMessage(plugin.msg("players-only"));
                return;
            }
            s.sendMessage(plugin.msg("balance-self", "balance", eco.format(eco.get(p.getUniqueId()))));
            return;
        }
        UUID id = eco.findByName(args[0]);
        if (id == null) {
            s.sendMessage(plugin.msg("player-not-found"));
            return;
        }
        s.sendMessage(plugin.msg("balance-other", "player", eco.nameOf(id), "balance", eco.format(eco.get(id))));
    }

    private void pay(CommandSender s, String[] args) {
        if (!(s instanceof Player p)) {
            s.sendMessage(plugin.msg("players-only"));
            return;
        }
        if (args.length < 2) {
            s.sendMessage(plugin.msg("pay-usage"));
            return;
        }
        UUID target = eco.findByName(args[0]);
        if (target == null) {
            s.sendMessage(plugin.msg("player-not-found"));
            return;
        }
        if (target.equals(p.getUniqueId())) {
            s.sendMessage(plugin.msg("pay-self"));
            return;
        }
        double amount;
        try {
            amount = EconomyManager.round(EconomyManager.parse(args[1]));
        } catch (NumberFormatException ex) {
            s.sendMessage(plugin.msg("invalid-amount"));
            return;
        }
        if (amount < 0.01) {
            s.sendMessage(plugin.msg("invalid-amount"));
            return;
        }
        if (!eco.has(p.getUniqueId(), amount)) {
            s.sendMessage(plugin.msg("not-enough-money", "price", eco.format(amount),
                    "balance", eco.format(eco.get(p.getUniqueId()))));
            return;
        }
        eco.withdraw(p.getUniqueId(), amount);
        eco.add(target, amount);
        s.sendMessage(plugin.msg("pay-sent", "amount", eco.format(amount), "player", eco.nameOf(target)));
        Player online = Bukkit.getPlayer(target);
        if (online != null) {
            online.sendMessage(plugin.msg("pay-received", "amount", eco.format(amount), "player", p.getName()));
        }
    }

    private void baltop(CommandSender s) {
        s.sendMessage(plugin.msg("baltop-header"));
        int pos = 1;
        for (Map.Entry<UUID, Double> e : eco.top(10)) {
            s.sendMessage(plugin.msg("baltop-line", "pos", pos++, "player", eco.nameOf(e.getKey()),
                    "balance", eco.format(e.getValue())));
        }
    }

    private void ecoAdmin(CommandSender s, String[] args) {
        if (!s.hasPermission(ADMIN)) {
            s.sendMessage(plugin.msg("no-permission"));
            return;
        }
        if (args.length < 3) {
            s.sendMessage(plugin.msg("eco-usage"));
            return;
        }
        UUID target = eco.findByName(args[1]);
        if (target == null) {
            s.sendMessage(plugin.msg("player-not-found"));
            return;
        }
        double amount;
        try {
            amount = EconomyManager.parse(args[2]);
        } catch (NumberFormatException ex) {
            s.sendMessage(plugin.msg("invalid-amount"));
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "give" -> eco.add(target, amount);
            case "take" -> eco.set(target, eco.get(target) - amount);
            case "set" -> eco.set(target, amount);
            default -> {
                s.sendMessage(plugin.msg("eco-usage"));
                return;
            }
        }
        s.sendMessage(plugin.msg("eco-done", "player", eco.nameOf(target), "balance", eco.format(eco.get(target))));
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        String n = cmd.getName().toLowerCase(Locale.ROOT);
        List<String> out = new ArrayList<>();
        if (n.equals("shop") && args.length == 1 && sender.hasPermission(ADMIN)) {
            out.add("reload");
        } else if ((n.equals("balance") || n.equals("pay")) && args.length == 1) {
            for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
        } else if (n.equals("eco") && sender.hasPermission(ADMIN)) {
            if (args.length == 1) {
                out.add("give");
                out.add("take");
                out.add("set");
            } else if (args.length == 2) {
                for (Player p : Bukkit.getOnlinePlayers()) out.add(p.getName());
            }
        }
        String last = args.length == 0 ? "" : args[args.length - 1].toLowerCase(Locale.ROOT);
        out.removeIf(x -> !x.toLowerCase(Locale.ROOT).startsWith(last));
        return out;
    }
}
