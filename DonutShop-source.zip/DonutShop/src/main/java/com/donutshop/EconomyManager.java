package com.donutshop;

import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class EconomyManager {

    private final DonutShop plugin;
    private final File file;
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();

    public EconomyManager(DonutShop plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "balances.yml");
    }

    public void load() {
        balances.clear();
        names.clear();
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yml.getConfigurationSection("players");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                UUID id = UUID.fromString(key);
                balances.put(id, sec.getDouble(key + ".balance"));
                String n = sec.getString(key + ".name");
                if (n != null) names.put(id, n);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Double> e : balances.entrySet()) {
            String k = "players." + e.getKey();
            yml.set(k + ".balance", e.getValue());
            String n = names.get(e.getKey());
            if (n != null) yml.set(k + ".name", n);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().severe("Falha ao salvar balances.yml: " + ex.getMessage());
        }
    }

    public void touch(Player p) {
        names.put(p.getUniqueId(), p.getName());
        get(p.getUniqueId());
    }

    public double get(UUID id) {
        return balances.computeIfAbsent(id, k -> plugin.getConfig().getDouble("start-balance", 1000.0));
    }

    public boolean has(UUID id, double amount) {
        return get(id) + 1e-9 >= amount;
    }

    public void set(UUID id, double amount) {
        balances.put(id, round(Math.max(0, amount)));
    }

    public void add(UUID id, double amount) {
        set(id, get(id) + amount);
    }

    public boolean withdraw(UUID id, double amount) {
        if (!has(id, amount)) return false;
        set(id, get(id) - amount);
        return true;
    }

    public String nameOf(UUID id) {
        return names.getOrDefault(id, "desconhecido");
    }

    public UUID findByName(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online.getUniqueId();
        for (Map.Entry<UUID, String> e : names.entrySet()) {
            if (e.getValue().equalsIgnoreCase(name)) return e.getKey();
        }
        return null;
    }

    public List<Map.Entry<UUID, Double>> top(int n) {
        List<Map.Entry<UUID, Double>> list = new ArrayList<>(balances.entrySet());
        list.sort((a, b) -> Double.compare(b.getValue(), a.getValue()));
        return list.size() > n ? new ArrayList<>(list.subList(0, n)) : list;
    }

    public static double round(double v) {
        return Math.round(v * 100.0) / 100.0;
    }

    /** Formata como $1.5K, $2.3M, $1,250 etc. */
    public String format(double v) {
        String currency = plugin.getConfig().getString("currency", "$");
        double a = Math.abs(v);
        double d = v;
        String suffix = "";
        if (a >= 1e12) { d = v / 1e12; suffix = "T"; }
        else if (a >= 1e9) { d = v / 1e9; suffix = "B"; }
        else if (a >= 1e6) { d = v / 1e6; suffix = "M"; }
        else if (a >= 1e3) { d = v / 1e3; suffix = "K"; }

        String num;
        if (suffix.isEmpty()) {
            num = (d == Math.rint(d))
                    ? String.format(Locale.US, "%,.0f", d)
                    : String.format(Locale.US, "%,.2f", d);
        } else {
            num = String.format(Locale.US, "%.2f", d).replaceAll("0+$", "").replaceAll("\\.$", "");
        }
        return currency + num + suffix;
    }

    /** Aceita 100, 2.5k, 1,5m (vírgula = decimal), 3b, 1t. */
    public static double parse(String input) {
        String s = input.trim().toLowerCase(Locale.ROOT).replace(',', '.');
        double mult = 1;
        if (s.endsWith("k")) { mult = 1e3; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("m")) { mult = 1e6; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("b")) { mult = 1e9; s = s.substring(0, s.length() - 1); }
        else if (s.endsWith("t")) { mult = 1e12; s = s.substring(0, s.length() - 1); }
        double v = Double.parseDouble(s) * mult;
        if (Double.isNaN(v) || Double.isInfinite(v)) throw new NumberFormatException("invalid");
        return v;
    }
}
