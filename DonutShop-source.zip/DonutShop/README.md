# DonutShop

Loja estilo DonutSMP para Paper 26.1.2, **sem spawners** (bloqueados no código).

Comandos: /shop (/loja), /sell (/vender), /bal, /pay, /baltop, /eco (admin), /shop reload (admin)

Compilar: `mvn package` com JDK 25 -> `target/DonutShop.jar`
Instalar: coloque o .jar em `plugins/` e reinicie o servidor.
Edite `plugins/DonutShop/shop.yml` e `config.yml` para mudar itens, preços e mensagens.
